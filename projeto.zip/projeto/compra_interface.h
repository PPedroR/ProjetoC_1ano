#ifndef COMPRA_INTERFACE_H_INCLUDED
#define COMPRA_INTERFACE_H_INCLUDED

void compra_eurusd()
{
        printf(R"EOF(
         ___ ___ _____   __  __  ___  ___ ___    ___ ___  __  __ ___  _   _  ___   __
        / __| __|_   _| |  \/  |/ _ \| _ \ __|  / __/ _ \|  \/  | _ \/_\ | \| \ \ / /
       | (_ | _|  | |   | |\/| | (_) |   / _|  | (_| (_) | |\/| |  _/ _ \| .` |\ V /
        \___|___| |_|   |_|  |_|\___/|_|_\___|  \___\___/|_|  |_|_|/_/ \_\_|\_| |_|
    )EOF");

    printf("\n   |Compra\n\n");
    textcolor(WHITE);
    printf("                            |");
    textcolor(LIGHTRED);
    printf(" EUR/USD ");
    textcolor(WHITE);
    printf("|");
    printf(" GBP/USD ");
    printf("|");
    printf(" EUR/GBP ");
    printf("|");
    printf(" GBP/JPY ");
    printf("|\n\n");
    return 0;
}


void compra_gbpusd()
{
        printf(R"EOF(
         ___ ___ _____   __  __  ___  ___ ___    ___ ___  __  __ ___  _   _  ___   __
        / __| __|_   _| |  \/  |/ _ \| _ \ __|  / __/ _ \|  \/  | _ \/_\ | \| \ \ / /
       | (_ | _|  | |   | |\/| | (_) |   / _|  | (_| (_) | |\/| |  _/ _ \| .` |\ V /
        \___|___| |_|   |_|  |_|\___/|_|_\___|  \___\___/|_|  |_|_|/_/ \_\_|\_| |_|
    )EOF");

    printf("\n   |Compra\n\n");
    textcolor(WHITE);
    printf("                            |");
    printf(" EUR/USD ");
    printf("|");
    textcolor(LIGHTRED);
    printf(" GBP/USD ");
    textcolor(WHITE);
    printf("|");
    printf(" EUR/GBP ");
    printf("|");
    printf(" GBP/JPY ");
    printf("|\n\n");
    return 0;
}


void compra_eurgbp()
{
        printf(R"EOF(
         ___ ___ _____   __  __  ___  ___ ___    ___ ___  __  __ ___  _   _  ___   __
        / __| __|_   _| |  \/  |/ _ \| _ \ __|  / __/ _ \|  \/  | _ \/_\ | \| \ \ / /
       | (_ | _|  | |   | |\/| | (_) |   / _|  | (_| (_) | |\/| |  _/ _ \| .` |\ V /
        \___|___| |_|   |_|  |_|\___/|_|_\___|  \___\___/|_|  |_|_|/_/ \_\_|\_| |_|
    )EOF");

    printf("\n   |Compra\n\n");
    textcolor(WHITE);
    printf("                            |");
    printf(" EUR/USD ");
    printf("|");
    printf(" GBP/USD ");
    printf("|");
    textcolor(LIGHTRED);
    printf(" EUR/GBP ");
    textcolor(WHITE);
    printf("|");
    printf(" GBP/JPY ");
    printf("|\n\n");
    return 0;
}


void compra_gbpjpy()
{
        printf(R"EOF(
         ___ ___ _____   __  __  ___  ___ ___    ___ ___  __  __ ___  _   _  ___   __
        / __| __|_   _| |  \/  |/ _ \| _ \ __|  / __/ _ \|  \/  | _ \/_\ | \| \ \ / /
       | (_ | _|  | |   | |\/| | (_) |   / _|  | (_| (_) | |\/| |  _/ _ \| .` |\ V /
        \___|___| |_|   |_|  |_|\___/|_|_\___|  \___\___/|_|  |_|_|/_/ \_\_|\_| |_|
    )EOF");
    printf("\n   |Compra\n\n");
    textcolor(WHITE);
    printf("                            |");
    printf(" EUR/USD ");
    printf("|");
    printf(" GBP/USD ");
    printf("|");
    printf(" EUR/GBP ");
    printf("|");
    textcolor(LIGHTRED);
    printf(" GBP/JPY ");
    textcolor(WHITE);
    printf("|\n\n");
    return 0;
}
#endif // COMPRA_INTERFACE_H_INCLUDED

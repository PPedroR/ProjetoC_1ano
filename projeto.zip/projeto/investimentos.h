#ifndef INVESTIMENTOS_H_INCLUDED
#define INVESTIMENTOS_H_INCLUDED
#include "investimentos_interface.h"
#include "compra.h"

int investimentos()
{
    char w[10]="w";
    char s[10]="s";
    char e[10]="e";
    char op1[10];
    int c,t,b,j,y=1,a=1,u=0,es=1;
    investimentos_comprar();
    do{
        gets(op1);
        c=strcmp(op1,w);
        t=strcmp(op1,s);
        j=strcmp(op1,e);
        system("cls");
        if(c==0)
        {
            es=es-1;
        }
        else if(t==0)
        {
            es=es+1;
        }
        else if(j==0)
        {
            es=10;
        }
        else{
            textcolor(RED);
            printf("  erro\n");
            textcolor(WHITE);
        }
        switch(es)
        {
            case 1:
                investimentos_comprar();
                a=1;
                y=1;
                b=1;
                break;
            case 2:
                investimentos_vender();
                a=2;
                y=2;
                b=1;
                break;
            case 3:
                investimentos_fechar();
                a=3;
                y=3;
                b=1;
                break;
            case 4:
                investimentos_historico();
                a=4;
                y=4;
                b=1;
                break;
            case 10:
                if(a==1 && y==1)
                {
                  u=1;
                }
                else if(a==2 && y==2)
                {
                  u=2;
                }
                else if(a==3 && y==3)
                {
                  u=3;
                }
                else{
                  u=4;
                }
                b=0;
                break;
            default:
                investimentos_comprar();
                a=1;
                y=1;
                es=1;
                b=1;
                break;
        }
    }while(b==1);
    switch(u)
    {
        case 1:
            compra();
            break;
        case 2:
            //venda
            break;
        case 3:
            //fechar posi�oes
            break;
        case 4:
            //historico
            break;
    }
    return 0;
}

#endif // INVESTIMENTOS_H_INCLUDED

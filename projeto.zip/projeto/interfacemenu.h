#ifndef INTERFACEMENU_H_INCLUDED
#define INTERFACEMENU_H_INCLUDED
#include "conio.h"

void interface_investimentos()
{
    logo();
    textcolor(LIGHTBLUE);
    printf("\n     |Investimentos\n");
    textcolor(WHITE);
    printf("     |Depositar\n");
    printf("     |Levantar\n");
    printf("     |Historico de transa��es\n");
    printf("     |Outras op��es\n");
    printf("     |Sair\n\n");
    return 0;
}

void interface_depositar()
{
    logo();
    textcolor(WHITE);
    printf("\n     |Investimentos\n");
    textcolor(LIGHTBLUE);
    printf("     |Depositar\n");
    textcolor(WHITE);
    printf("     |Levantar\n");
    printf("     |Historico de transa��es\n");
    printf("     |Outras op��es\n");
    printf("     |Sair\n\n");
    return 0;
}

void interface_levantar()
{
    logo();
    textcolor(WHITE);
    printf("\n     |Investimentos\n");
    printf("     |Depositar\n");
    textcolor(LIGHTBLUE);
    printf("     |Levantar\n");
    textcolor(WHITE);
    printf("     |Historico de transa��es\n");
    printf("     |Outras op��es\n");
    printf("     |Sair\n\n");
    return 0;
}

void interface_historico()
{
    logo();
    textcolor(WHITE);
    printf("\n     |Investimentos\n");
    printf("     |Depositar\n");
    printf("     |Levantar\n");
    textcolor(LIGHTBLUE);
    printf("     |Historico de transa��es\n");
    textcolor(WHITE);
    printf("     |Outras op��es\n");
    printf("     |Sair\n\n");
    return 0;
}

void interface_outras()
{
    logo();
    textcolor(WHITE);
    printf("\n     |Investimentos\n");
    printf("     |Depositar\n");
    printf("     |Levantar\n");
    printf("     |Historico de transa��es\n");
    textcolor(LIGHTBLUE);
    printf("     |Outras op��es\n");
    textcolor(WHITE);
    printf("     |Sair\n\n");
    return 0;
}

void interface_sair()
{
    logo();
    textcolor(WHITE);
    printf("\n     |Investimentos\n");
    printf("     |Depositar\n");
    printf("     |Levantar\n");
    printf("     |Historico de transa��es\n");
    printf("     |Outras op��es\n");
    textcolor(LIGHTBLUE);
    printf("     |Sair\n\n");
    textcolor(WHITE);
    return 0;
}
#endif // INTERFACEMENU_H_INCLUDED

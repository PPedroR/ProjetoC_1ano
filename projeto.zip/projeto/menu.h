#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include "interfacemenu.h"
#include "investimentos.h"


int menu()
{
    char w[10]="w";
    char s[10]="s";
    char e[10]="e";
    char op1[10];
    int c,t,b,j,y=1,a=1,u=0,es=1;
    interface_investimentos();
    do{
        gets(op1);
        c=strcmp(op1,w);
        t=strcmp(op1,s);
        j=strcmp(op1,e);
        system("cls");
        if(c==0)
        {
            es=es-1;
        }
        else if(t==0)
        {
            es=es+1;
        }
        else if(j==0)
        {
            es=10;
        }
        else{
            textcolor(RED);
            printf("  erro\n");
            textcolor(WHITE);
        }
        switch(es)
        {
            case 1:
                interface_investimentos();
                b=1;
                a=1;
                y=1;
                break;
            case 2:
                interface_depositar();
                b=1;
                a=2;
                y=2;
                break;
            case 3:
                interface_levantar();
                b=1;
                a=3;
                y=3;
                break;
            case 4:
                interface_historico();
                b=1;
                a=4;
                y=4;
                break;
            case 5:
                interface_outras();
                b=1;
                a=5;
                y=5;
                break;
            case 6:
                interface_sair();
                b=1;
                a=6;
                y=6;
                break;
            case 10:
                if(a==1 && y==1)
                {
                  u=1;
                }
                else if(a==2 && y==2)
                {
                  u=2;
                }
                else if(a==3 && y==3)
                {
                  u=3;
                }
                else if(a==4 && y==4)
                {
                  u=4;
                }
                else if(a==5 && y==5)
                {
                  u=5;
                }
                else{
                  u=6;
                }
                b=0;
                break;
            default:
                interface_investimentos();
                y=1;
                a=1;
                es=1;
                b=1;
                break;
        }
    }while(b==1);
    switch(u)
    {
    case 1:
        investimentos();
        break;
    case 2:
        //depositar
        break;
    case 3:
        //levantar
        break;
    case 4:
        //historico
        break;
    case 5:
        //outras
        break;
    case 6:
        printf("ola");
        //sair
        break;
    default:break;
    }
    return 0;
}
#endif // MENU_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <locale.h>
#include "interfaceinicial.h"
#include "menu.h"
#include "criarconta.h"
#include "login.h"

int main()
{
    char w[10]="w";
    char s[10]="s";
    char e[10]="e";
    char op1[10];
    int c,t,b,j,y;
    textcolor(WHITE);
    inicioentrar();
    y=1;
    do{
    gets(op1);
    c=strcmp(op1,w);
    t=strcmp(op1,s);
    j=strcmp(op1,e);
    if(c==0)
    {
        system("cls");
        inicioentrar();
        y=1;
        b=1;
    }
    else if(t==0)
    {
        system("cls");
        iniciocriarconta();
        b=1;
        y=2;
    }
    else if(j==0)
    {

        b=0;
    }
    else{
        system("cls");
        inicioentrar();
        y=1;
        b=1;
    }
    }while(b==1);
    system("cls");
    if(y==2)
    {
        criarconta();
    }
    system("cls");
    login();
    menu();
    return 0;
}

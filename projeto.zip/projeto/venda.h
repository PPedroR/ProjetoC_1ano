#ifndef VENDA_H_INCLUDED
#define VENDA_H_INCLUDED

int venda(){
    char d[10]="d";
    char a[10]="a";
    char e[10]="e";
    char op1[10];
    int c,t,b,j,y=1,p=1,u=0,es=1;
    compra_eurusd();
    do{
        gets(op1);
        c=strcmp(op1,a);
        t=strcmp(op1,d);
        j=strcmp(op1,e);
        system("cls");
        if(c==0)
        {
            es=es-1;
        }
        else if(t==0)
        {
            es=es+1;
        }
        else if(j==0)
        {
            es=10;
        }
        else{
            textcolor(RED);
            printf("  erro\n");
            textcolor(WHITE);
        }
        switch(es)
        {
            case 1:
                venda_eurusd();
                p=1;
                y=1;
                b=1;
                break;
            case 2:
                venda_gbpusd();
                p=2;
                y=2;
                b=1;
                break;
            case 3:
                venda_eurgbp();
                p=3;
                y=3;
                b=1;
                break;
            case 4:
                venda_gbpjpy();
                p=4;
                y=4;
                b=1;
                break;
            case 10:
                if(p==1 && y==1)
                {
                  u=1;
                }
                else if(p==2 && y==2)
                {
                  u=2;
                }
                else if(p==3 && y==3)
                {
                  u=3;
                }
                else{
                  u=4;
                }
                b=0;
                break;
            default:
                venda_eurusd();
                p=1;
                y=1;
                es=1;
                b=1;
                break;
        }
    }while(b==1);
    switch(u)
    {
        case 1:
            par_eurusd();
            break;
        case 2:
            par_gbpusd();
            break;
        case 3:
            par_eurgbp();
            break;
        case 4:
            par_gbpjpy();
            break;
        }
    return 0;
}
return 0;
}

#endif // VENDA_H_INCLUDED

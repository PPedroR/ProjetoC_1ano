#ifndef CRIARCONTA_H_INCLUDED
#define CRIARCONTA_H_INCLUDED
#include <locale.h>

struct rgcadastro {

    char nome[25];
    char apelido[25];
    char pais[30];
    char morada[100];
    char email[70];
    int telefone;
    char senha[25];
    int depositoinicial;
    }cadastro;

int criarconta()
{
    char user;
    setlocale(LC_ALL,"Portuguese");
    logo();
    printf("  'Cria��o de conta'\n");
    printf("|Nome: ");
    gets(cadastro.nome);
    printf("|Apelido: ");
    gets(cadastro.apelido);
    printf("|Pais de residencia: ");
    gets(cadastro.pais);
    printf("|Morada: ");
    gets(cadastro.morada);
    printf("|Email: ");
    gets(cadastro.email);
    printf("|Senha: ");
    gets(cadastro.senha);
    printf("|Telefone: ");
    scanf("%i",&cadastro.telefone);
    printf("|Deposito inicial: ");
    scanf("%i",&cadastro.depositoinicial);
    fflush(stdin);
    system("cls");
    logo();
    printf("                                = Conta criada com ");
    textcolor(GREEN);
    printf("sucesso! ");
    textcolor(WHITE);
    printf("=\n\n");
    system("Pause");
    strcat(cadastro.nome,cadastro.senha);

    FILE*ficheiro;
    ficheiro=fopen(cadastro.nome,"w+");
    fprintf(ficheiro,"  'Cadastro de %s.'\n",cadastro.nome);
    fprintf(ficheiro,"|Nome: %s\n|Apelido: %s\n|Pais de residencia: %s\n|Morada: %s\n|Email: %s\n|Telefone: %i\n|Senha: %s\n|Deposito inicial: %i$\n",cadastro.nome,cadastro.apelido,cadastro.pais,cadastro.morada,cadastro.email,cadastro.telefone,cadastro.senha,cadastro.depositoinicial);
    fclose(ficheiro);

    return 0;
}

#endif // CRIARCONTA_H_INCLUDED

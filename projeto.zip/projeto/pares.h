#ifndef PARES_H_INCLUDED
#define PARES_H_INCLUDED
#include "login.h"

int par_eurusd(){

    char h[25]="eurusd";
    logo();
    grafico1();
    textcolor(GREEN);
    printf("\n                         +10 Lotes ");
    textcolor(WHITE);
    printf("Comprados com ");
    textcolor(GREEN);
    printf("sucesso");
    textcolor(WHITE);
    printf(" no par EUR/USD!\n\n\n");
    FILE*ficheiro;
    strcat(h,nomesenha.nome1);
    ficheiro=fopen(h,"a+");
    fprintf(ficheiro,"|Compra:\n  |+10 Lotes\n  |EUR/USD\n\n");
    fclose(ficheiro);
    return 0;
}

int par_gbpusd(){

    char h[25]="gbpusd";
    logo();
    grafico2();
    textcolor(GREEN);
    printf("\n                          +10 Lotes ");
    textcolor(WHITE);
    printf("Comprados com ");
    textcolor(GREEN);
    printf("sucesso");
    textcolor(WHITE);
    printf(" no par GBP/USD!\n\n\n");
    FILE*ficheiro;
    strcat(h,nomesenha.nome1);
    ficheiro=fopen(h,"a+");
    fprintf(ficheiro,"|Compra:\n  |+10 Lotes\n  |GBP/USD\n\n");
    fclose(ficheiro);
    return 0;
}

int par_eurgbp(){

    char h[25]="eurgbp";
    logo();
    grafico3();
    textcolor(GREEN);
    printf("\n                          +10 Lotes ");
    textcolor(WHITE);
    printf("Comprados com ");
    textcolor(GREEN);
    printf("sucesso");
    textcolor(WHITE);
    printf(" no par EUR/GBP!\n\n\n");
    FILE*ficheiro;
    strcat(h,nomesenha.nome1);
    ficheiro=fopen(h,"a+");
    fprintf(ficheiro,"|Compra:\n  |+10 Lotes\n  |EUR/GBP\n\n");
    fclose(ficheiro);
    return 0;
}

int par_gbpjpy(){

    char h[25]="gbpjpy";
    logo();
    grafico4();
    textcolor(GREEN);
    printf("\n                          +10 Lotes ");
    textcolor(WHITE);
    printf("Comprados com ");
    textcolor(GREEN);
    printf("sucesso");
    textcolor(WHITE);
    printf(" no par GBP/JPY!\n\n\n");
    FILE*ficheiro;
    strcat(h,nomesenha.nome1);
    ficheiro=fopen(h,"a+");
    fprintf(ficheiro,"|Compra:\n  |+10 Lotes\n  |GBP/JPY\n\n");
    fclose(ficheiro);
    return 0;
}

#endif // PARES_H_INCLUDED

#ifndef INVESTIMENTOS_INTERFACE_H_INCLUDED
#define INVESTIMENTOS_INTERFACE_H_INCLUDED

void investimentos_comprar()
{
    logo();
    textcolor(LIGHTBLUE);
    printf("\n  |Investimentos\n\n");
    textcolor(LIGHTBLUE);
    printf("       |Comprar\n");
    textcolor(WHITE);
    printf("       |Vender\n");
    printf("       |Fechar posi��es\n");
    printf("       |Historico de posi��es\n");

    return 0;
}

void investimentos_vender()
{
    logo();
    textcolor(LIGHTBLUE);
    printf("\n  |Investimentos\n\n");
    textcolor(WHITE);
    printf("       |Comprar\n");
    textcolor(LIGHTBLUE);
    printf("       |Vender\n");
    textcolor(WHITE);
    printf("       |Fechar posi��es\n");
    printf("       |Historico de posi��es\n");
    return 0;
}

void investimentos_fechar()
{
    logo();
    textcolor(LIGHTBLUE);
    printf("\n  |Investimentos\n\n");
    textcolor(WHITE);
    printf("       |Comprar\n");
    printf("       |Vender\n");
    textcolor(LIGHTBLUE);
    printf("       |Fechar posi��es\n");
    textcolor(WHITE);
    printf("       |Historico de posi��es\n");
    return 0;
}


void investimentos_historico()
{
    logo();
    textcolor(LIGHTBLUE);
    printf("\n  |Investimentos\n\n");
    textcolor(WHITE);
    printf("       |Comprar\n");
    printf("       |Vender\n");
    printf("       |Fechar posi��es\n");
    textcolor(LIGHTBLUE);
    printf("       |Historico de posi��es\n");
    textcolor(WHITE);
    return 0;
}


#endif // INVESTIMENTOS_INTERFACE_H_INCLUDED

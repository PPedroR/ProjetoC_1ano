#ifndef LOGIN_H_INCLUDED
#define LOGIN_H_INCLUDED

struct rgnomesenha{

char nome1[25];
int senha1[25];
}nomesenha;

int login()
{
    setlocale(LC_ALL,"Portuguese");
    char nome1[25],senha1[25];
    int b;
    do{
    logo();
    printf("     |Nome: ");
    gets(nomesenha.nome1);
    printf("     |Senha: ");
    gets(nomesenha.senha1);
    strcat(nomesenha.nome1,nomesenha.senha1);
    FILE*ficheiro;
    ficheiro=fopen(nomesenha.nome1,"r");
    if(!ficheiro)
    {
        system("cls");
        logo();
        textcolor(RED);
        printf("\n                                    Conta n�o encontrada!\n\n");
        textcolor(WHITE);
        system("Pause");
        textcolor(WHITE);
        system("cls");
        b=1;
    }
    else{
        b=0;
    }
    fclose(ficheiro);
}while(b==1);
system("cls");
    return 0;
}

#endif // LOGIN_H_INCLUDED
